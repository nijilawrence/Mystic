<?php

?>
<div id="wrapper">
	<div id="header">
		<div class="logo">
			<?php if ($logo): ?>
			<a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home" id="logo">
				<img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
			</a>
			<?php endif; ?>
		</div>
<!--															<?php if ($main_menu): ?>
																		<div id="main-menu">
																			<?php print theme('links__system_main_menu', array(
																				'links' => $main_menu,
																				'attributes' => array(
																					'id' => 'main-menu-links',
																					'class' => array('links', 'clearfix'),
																				),
																				'heading' => array(
																					'text' => t('Main menu'),
																					'level' => 'h2',
																					'class' => array('element-invisible'),
																				),
																			)); ?>
																		</div>
																	<?php endif; ?>
-->
		<?php if($page['mainmenu']) { ?>
				<div id="main-menu">
					<?php print render($page['mainmenu']); ?>
				</div>
		<?php }
			else {
		?>
				<div id="main-menu">
					<ul id="main-menu-links" class="links clearfix">
						<li class="first"><a href="#" class="active">Home</a></li>
						<li><a href="#">News</a></li>
						<li><a href="#" title="">About us</a></li>
						<li class="last"><a href="#" title="Contact page">Contact us</a></li>
					</ul>	
				</div>
		<?php } ?>
	</div>
	<div id="content">
		<?php 
			if($page['slider']) { 
		?>
			<div class="slider">
				<?php print render($page['slider']); ?>
			</div>
		<?php 
			} 
			else {
		?>
		<div class="slider">
			<img src="sites/all/themes/mystic/images/slider_pic1.jpg" height="500px" width="960px" />
		</div>		
		<?php				
			}
		?>
	</div>
	<?php if ($page['footer_first'] || $page['footer_second'] || $page['footer_third']): ?>
		<div id="footercontainer">
			<?php if ($page['footer_first']): ?>
				<div class="footerfirst">
					<?php print render($page['footer_first']); ?>
				</div>
			<?php endif; ?>
			<?php if ($page['footer_second']): ?>
			<div class="footersecond">
				<?php print render($page['footer_second']); ?>
			</div>
			<?php endif; ?>
			<?php if ($page['footer_third']): ?>
			<div class="footerthird">
				<?php print render($page['footer_third']); ?>
			</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<?php if ($page['footer']): ?>
	<div id="footer">
		<?php print render($page['footer']); ?>
	</div>
	<?php endif; ?>
</div> <!-- /#wrapper -->

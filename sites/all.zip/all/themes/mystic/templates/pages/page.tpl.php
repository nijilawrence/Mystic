<?php
$i=0;
?>
<div id="wrapper">
	<div id="header">
		<div class="logo">
			<?php if ($logo): ?>
			<a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home" id="logo">
				<img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
			</a>
			<?php endif; ?>
		</div>
		<?php if ($main_menu): ?>
      <div id="main-menu">
        <?php print theme('links__system_main_menu', array(
          'links' => $main_menu,
          'attributes' => array(
            'id' => 'main-menu-links',
            'class' => array('links', 'clearfix'),
          ),
          'heading' => array(
            'text' => t('Main menu'),
            'level' => 'h2',
            'class' => array('element-invisible'),
          ),
        )); ?>
      </div> <!-- /#main-menu -->
    <?php endif; ?>
	</div>
	<div id="content">
		<?php 
		if($page['sidebar_first'] && $page['sidebar_second']) {
		?>
			<div class="sidebar-first">
				<?php print render($page['sidebar_first']); ?>
			</div>
			<div class="maincontentmiddle">
				<?php print render($page['content']); ?>
			</div>
			<div class="sidebar-second">
				<?php print render($page['sidebar_second']); ?>
			</div>
		<?php 
		}
		elseif($page['sidebar_first']) {
		?>
			<div class="sidebar-first">
				<?php print render($page['sidebar_first']); ?>
			</div>
			<div class="maincontentside">
				<?php print render($page['content']); ?>
			</div>
		<?php
		}
		elseif($page['sidebar_second']) {
		?>
			<div class="maincontentside">
				<?php print render($page['content']); ?>
			</div>
			<div class="sidebar-second">
				<?php print render($page['sidebar_second']); ?>
			</div>
		<?php
		}
		else {
		?>
			<div class="maincontentfull">
				<?php print render($page['content']); ?>
			</div>
		<?php 
		}
		?>
	</div>
	<?php if ($page['footer_first'] || $page['footer_second'] || $page['footer_third']): ?>
		<div id="footercontainer">
			<?php if ($page['footer_first']): ?>
				<div class="footerfirst">
					<?php print render($page['footer_first']); ?>
				</div>
			<?php endif; ?>
			<?php if ($page['footer_second']): ?>
			<div class="footersecond">
				<?php print render($page['footer_second']); ?>
			</div>
			<?php endif; ?>
			<?php if ($page['footer_third']): ?>
			<div class="footerthird">
				<?php print render($page['footer_third']); ?>
			</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<?php if ($page['footer']): ?>
	<div id="footer">
		<?php print render($page['footer']); ?>
	</div>
	<?php endif; ?>
</div> <!-- /#wrapper -->
